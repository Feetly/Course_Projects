/etc/apache2/sites-enabled/default-ssl.conf
/etc/ssl/certificate.crt
/etc/ssl/ca_bundle.crt
/etc/ssl/private/private.key